load rainfallTest.mat
load rainfallTrain.mat
load rainfallFuture.mat

%Regression tree model
mdlTree = RegressionTree.fit(trainX,trainY,'PredictorNames',label);

% Store Forecasts in a stucture
forecast(1).Y = predict(mdlTree,testX);

%Neural Network Model
net = fitnet(20);
net = train(net, trainX', trainY');

forecast(2).Y = net(testX')';

%Bagged Decision Trees Model

mdlTreeBag = TreeBagger(100, trainX, trainY, 'method', 'regression', ...
                       'oobpred', 'on', 'minleaf', 30);

forecast(3).Y = predict(mdlTreeBag, testX);

%glm regression model
glme = fitlm(trainX, trainY,'linear');
forecast(4).Y = predict(glme, testX);


    Data_Inputs=xlsread('weatherstats_montreal.xlsx'); % Import file
    Training_Set=Data_Inputs(1:end,2);%specific training set
    Target_Set=Data_Inputs(1:end,3); %specific target set
    Input=Training_Set'; %Convert to row
    Target=Target_Set'; %Convert to row
    X = con2seq(Input); %Convert to cell
    T = con2seq(Target); %Convert to cell
    %% 2. Data preparation
    N = 1365; % Multi-step ahead prediction
    % Input and target series are divided in two groups of data:
    % 1st group: used to train the network
    inputSeries  = X(1:end-N);
    targetSeries = T(1:end-N);
    inputSeriesVal  = X(end-N+1:end);
    targetSeriesVal = T(end-N+1:end); 
    % Create a Nonlinear Autoregressive Network with External Input
    delay = 5;
   
neuronsHiddenLayer = 10;
% Network Creation
net = narxnet(1:delay,1:delay,neuronsHiddenLayer);

%% 4. Training the network

[Xs,Xi,Ai,Ts] = preparets(net,inputSeries,{},targetSeries); 
net = train(net,Xs,Ts,Xi,Ai);
view(net)
Y = net(Xs,Xi,Ai); 
% Performance for the series-parallel implementation, only 
% one-step-ahead prediction
perf = perform(net,Ts,Y);
%% 5. Multi-step ahead prediction

inputSeriesPred  = [inputSeries(end-delay+1:end),inputSeriesVal];
targetSeriesPred = [targetSeries(end-delay+1:end), con2seq(nan(1,N))];
netc = closeloop(net);
view(netc)
[Xs,Xi,Ai,Ts] = preparets(netc,inputSeriesPred,{},targetSeriesPred);
yPred = netc(Xs,Xi,Ai);
perf = perform(net,yPred,targetSeriesVal);

forecast(4).Y = sim(netc,targetSeries);



%future prediction
%forecast(5).Y = predict(mdlTree,testFutureX);
forecast(5).Y = predict(glme,testFutureX);

idx = 1:1000;
Dates = idx + datenum('JAN-27-2016') -1;

%Regression Tree graphs
figure('Units','Normalized','Position',[0.05,0.4,0.4,0.5]), 
subplot(2,1,1)
hPlot1 = plot(Dates, [testY(idx),forecast(1).Y(idx)],'LineWidth',2);
set(hPlot1(1),'LineWidth',5,'Color',[1 1 0],'DisplayName','Actual');
set(hPlot1(2),'Color',[0 1 0],'DisplayName','Regression Tree');
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
ylabel('Rainfall'),
title('Rainfall Prediction with Regression Tree','FontSize',12,'FontWeight','Bold')

subplot(2,1,2)
hPlot2 = plot(Dates,[testY(idx)-forecast(1).Y(idx)]);
set(hPlot2(1),'Color',[0 1 0],'DisplayName','Regression Tree Error');
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
title('Prediction Error for Regression Tree','FontSize',12,'FontWeight','Bold')
ylabel('Residuals'), grid on
legend('show')

%Neural Network graphs
figure('Units','Normalized','Position',[0.05,0.4,0.4,0.5]), subplot(2,1,1)
hPlot3 = plot(Dates, [testY(idx),forecast(2).Y(idx)],'LineWidth',2);
set(hPlot3(1),'LineWidth',5,'Color',[1 1 0],'DisplayName','Actual');
set(hPlot3(2),'DisplayName','Neural Network');
legend('show'),
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
ylabel('Rainfall'),
title('Rainfall Prediction with Neural Network','FontSize',12,'FontWeight','Bold')

subplot(2,1,2)
hPlot4 = plot(Dates,[testY(idx)-forecast(2).Y(idx)]);
set(hPlot4(1),'Color','r','DisplayName','Neural Network Error');
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
title('Prediction Error for Neural Network','FontSize',12,'FontWeight','Bold')
ylabel('Residuals'), grid on
legend('show')

%Bagged Regression Tree graphs
figure('Units','Normalized','Position',[0.05,0.4,0.4,0.5]), subplot(2,1,1)
hPlot5 = plot(Dates, [testY(idx),forecast(3).Y(idx)],'LineWidth',2);
set(hPlot5(1),'LineWidth',5,'Color',[1 1 0],'DisplayName','Actual');
set(hPlot5(2),'Color',[0.5 0.5 0.5],'DisplayName','Bagged Regression Trees');
legend('show'),
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
ylabel('Rainfall'),
title('Rainfall Prediction with Bagged Regression Tree','FontSize',12,'FontWeight','Bold')

subplot(2,1,2)
hPlot6 = plot(Dates,[testY(idx)-forecast(3).Y(idx)]);
set(hPlot6(1),'Color',[0.5 0.5 0.5],'DisplayName','Bagged Regression Trees Error');
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
title('Prediction Error for Bagged Regression Trees','FontSize',12,'FontWeight','Bold')
ylabel('Residuals'), grid on
legend('show')
%Artificial neural networks graphs
figure('Units','Normalized','Position',[0.05,0.4,0.4,0.5]), subplot(2,1,1)
plot([cell2mat(targetSeries),nan(1,N);
      nan(1,length(targetSeries)),cell2mat(yPred);
      nan(1,length(targetSeries)),cell2mat(targetSeriesVal)]')
legend('Original Targets','Network Predictions','Expected Outputs')
subplot(2,1,2)
hPlot7 = plot(Dates,[testY(idx)-cell2mat(forecast(4).Y(idx))]);
set(hPlot7(1),'Color',[0.5 0.5 0.5],'DisplayName','ANN Error');
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
title('Prediction Error for ANN','FontSize',12,'FontWeight','Bold')
ylabel('Residuals'), grid on


idx = 1:7;
Dates = datenum('Aug-8-2018') + idx -1;

%Future graph
figure('Units','Normalized','Position',[0.05,0.4,0.4,0.5]), 
hPlot13 = plot(Dates, forecast(5).Y(idx),'LineWidth',2);
yl = ylim; % Get current limits.
ylim([0, yl(2)]);
set(hPlot13(1),'Color',[0 1 0],'DisplayName','NN');
legend('show'),
datetick('x','yyyy-mmm-dd','keepticks'), xlabel('Time'),
ylabel('Rainfall (cm)'),
title('Future Rainfall Prediction','FontSize',12,'FontWeight','Bold')



sumA = 0;
sumRTF = 0;
sumNeuF = 0;
sumBRTF = 0;
sumNNF = 0;

sumA = sum(testY);
sumRTF = sum(forecast(1).Y);
sumNeuF = sum(forecast(2).Y);
sumBRTF = sum(forecast(3).Y);
sumNNF = sum(cell2mat(forecast(4).Y));

% avg error percentage 
errRT = ((sumA - sumRTF)/sumA)*100;
errNeu = ((sumA - sumNeuF)/sumA)*100;
errBRT = ((sumA - sumBRTF)/sumA)*100;
errNN =  ((sumA - sumNNF)/sumA)*100;

fprintf('Model \t\t         Error percentage:-\n');
fprintf('Regression Tree \t %0.2f \n',errRT);
fprintf('Neural Network       \t%0.2f\n',errNeu);
fprintf('Bagged Regression Tree \t%0.2f\n',errBRT);
fprintf('Neural net \t%0.2f\n',errNN);

%END